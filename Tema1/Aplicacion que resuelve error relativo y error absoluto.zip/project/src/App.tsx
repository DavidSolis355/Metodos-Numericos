import React, { useState } from 'react';
import { Calculator } from 'lucide-react';

function App() {
  const [valorReal, setValorReal] = useState<string>('');
  const [valorAproximado, setValorAproximado] = useState<string>('');
  
  const calcularErrores = () => {
    const vReal = parseFloat(valorReal);
    const vAprox = parseFloat(valorAproximado);
    
    if (isNaN(vReal) || isNaN(vAprox)) return null;
    
    const errorAbsoluto = Math.abs(vReal - vAprox);
    const errorRelativo = (errorAbsoluto / Math.abs(vReal)) * 100;
    
    return {
      absoluto: errorAbsoluto.toFixed(4),
      relativo: errorRelativo.toFixed(2)
    };
  };

  const resultados = calcularErrores();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-lg p-8 w-full max-w-md">
        <div className="flex items-center gap-3 mb-6">
          <Calculator className="w-8 h-8 text-indigo-600" />
          <h1 className="text-2xl font-bold text-gray-800">
            Calculadora de Errores
          </h1>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Valor Real
            </label>
            <input
              type="number"
              value={valorReal}
              onChange={(e) => setValorReal(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="Ingrese el valor real"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Valor Aproximado
            </label>
            <input
              type="number"
              value={valorAproximado}
              onChange={(e) => setValorAproximado(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="Ingrese el valor aproximado"
            />
          </div>

          {resultados && (
            <div className="mt-6 space-y-4 bg-indigo-50 p-4 rounded-lg">
              <div>
                <h3 className="text-sm font-medium text-gray-700">Error Absoluto:</h3>
                <p className="text-lg font-semibold text-indigo-600">
                  {resultados.absoluto}
                </p>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-700">Error Relativo:</h3>
                <p className="text-lg font-semibold text-indigo-600">
                  {resultados.relativo}%
                </p>
              </div>
            </div>
          )}

          <div className="mt-4 text-sm text-gray-600">
            <p className="font-medium">Fórmulas utilizadas:</p>
            <ul className="list-disc list-inside mt-2 space-y-1">
              <li>Error Absoluto = |Valor Real - Valor Aproximado|</li>
              <li>Error Relativo = (Error Absoluto / |Valor Real|) × 100%</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;