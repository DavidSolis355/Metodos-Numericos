
package eliminaciongaussiana;

public class EliminacionGaussiana {

    public static void main(String[] args) {

        double[][] matriz = {
            {3, 2, 3, 3},
            {1, 3, 1, -6},
            {5, 1, 3, 12}
        };

        int orden = matriz.length;

        System.out.println("Matriz inicial:");
        mostrarMatriz(matriz, orden);

        for (int j = 0; j < orden; j++) {
            for (int i = 0; i < orden; i++) {
                if (i > j) {
                    double division = matriz[i][j] / matriz[j][j];
                    System.out.printf("Haciendo cero el elemento en fila %d, columna %d (usando fila %d):\n", i + 1, j + 1, j + 1);
                    System.out.printf("Factor de eliminacion = %.3f\n", division);
                    for (int k = 0; k < orden + 1; k++) {
                        matriz[i][k] = matriz[i][k] - division * matriz[j][k];
                    }
                    mostrarMatriz(matriz, orden);  
                }
            }
        }

        double[] x = new double[orden];

        System.out.println("Resolviendo por sustitucion hacia atras:");
        for (int i = orden - 1; i >= 0; i--) {
            double suma = 0;
            for (int j = i + 1; j < orden; j++) {
                suma += matriz[i][j] * x[j];
            }
            x[i] = (matriz[i][orden] - suma) / matriz[i][i];
            System.out.printf("x%d = %.3f\n", i, x[i]);
        }

        System.out.println("\nSolucion final:");
        for (int i = 0; i < orden; i++) {
            System.out.printf("x%d = %.3f\n", i, x[i]);
        }
    }

    
    public static void mostrarMatriz(double[][] matriz, int orden) {
        for (int i = 0; i < orden; i++) {
            String linea = "| ";
            for (int j = 0; j < orden + 1; j++) {
                linea += String.format("%8.3f", matriz[i][j]) + " ";
            }
            linea += "|";
            System.out.println(linea);
        }
        System.out.println();
    }
    
}
